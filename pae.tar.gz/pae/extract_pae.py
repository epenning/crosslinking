import pickle

RESULTS_PKL_SUFFIX = '-result_model_1_ptm.pkl'
PAE_PKL_SUFFIX = '-pae_model_1_ptm.pkl'

def sanitize_protein(protein_id):
	return protein_id.replace("/", "_") # Use _ instead of / for processing

def desanitize_protein(protein_sanitized):
	return protein_sanitized.replace("_", "/")

proteins = [
"MRNC57",
"I7MJ59",
"FTT18",
"BBC118",
"Q23A15",
"KARS",
"I7M6H8",
"TRAF3IP1",
"EIF4A",
"SPEF2",
"Q22MP6",
"RPS0"
]

for protein in proteins:
	sanitized_protein = sanitize_protein(protein)
	with open(sanitized_protein + RESULTS_PKL_SUFFIX, 'rb') as input_pkl:
		results = pickle.load(input_pkl)
	pae_output = {}
	pae_output['predicted_aligned_error'] = results['predicted_aligned_error']
	pae_output['max_predicted_aligned_error'] = results['max_predicted_aligned_error']
	with open(sanitized_protein + PAE_PKL_SUFFIX, 'wb') as output_pkl: 
		pickle.dump(pae_output, output_pkl)
